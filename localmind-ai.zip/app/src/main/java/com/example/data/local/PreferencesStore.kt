package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "nucleo_ia_prefs")

data class AppSettings(
    val linkedFolderUri: String? = null,
    val linkedFolderName: String? = null,
    val activeModelPath: String? = null,
    val activeBackend: String = "CPU", // "CPU" or "GPU"
    val strictOfflineMode: Boolean = true,
    val useTrainedContext: Boolean = true,
    val darkTheme: Boolean = true,
    val systemPersona: String = "Você é o Núcleo IA, uma LLM privada rodando 100% off-line no celular do usuário. Responda em português de forma clara, objetiva e priorize sempre os dados treinados da pasta vinculada quando estiverem disponíveis.",
    val temperature: Float = 0.7f,
    val topK: Int = 20,
    val topP: Float = 0.9f,
    val chunkSize: Int = 480,
    val chunkOverlap: Int = 96,
    val trainingEpochs: Int = 5
)

class PreferencesStore(private val context: Context) {
    private object Keys {
        val LINKED_FOLDER_URI = stringPreferencesKey("linked_folder_uri")
        val LINKED_FOLDER_NAME = stringPreferencesKey("linked_folder_name")
        val ACTIVE_MODEL_PATH = stringPreferencesKey("active_model_path")
        val ACTIVE_BACKEND = stringPreferencesKey("active_backend")
        val STRICT_OFFLINE = booleanPreferencesKey("strict_offline")
        val USE_TRAINED_CONTEXT = booleanPreferencesKey("use_trained_context")
        val DARK_THEME = booleanPreferencesKey("dark_theme")
        val SYSTEM_PERSONA = stringPreferencesKey("system_persona")
        val TEMPERATURE = floatPreferencesKey("temperature")
        val TOP_K = intPreferencesKey("top_k")
        val TOP_P = floatPreferencesKey("top_p")
        val CHUNK_SIZE = intPreferencesKey("chunk_size")
        val CHUNK_OVERLAP = intPreferencesKey("chunk_overlap")
        val TRAINING_EPOCHS = intPreferencesKey("training_epochs")
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            linkedFolderUri = prefs[Keys.LINKED_FOLDER_URI],
            linkedFolderName = prefs[Keys.LINKED_FOLDER_NAME],
            activeModelPath = prefs[Keys.ACTIVE_MODEL_PATH],
            activeBackend = prefs[Keys.ACTIVE_BACKEND] ?: "CPU",
            strictOfflineMode = prefs[Keys.STRICT_OFFLINE] ?: true,
            useTrainedContext = prefs[Keys.USE_TRAINED_CONTEXT] ?: true,
            darkTheme = prefs[Keys.DARK_THEME] ?: true,
            systemPersona = prefs[Keys.SYSTEM_PERSONA] ?: AppSettings().systemPersona,
            temperature = prefs[Keys.TEMPERATURE] ?: 0.7f,
            topK = prefs[Keys.TOP_K] ?: 20,
            topP = prefs[Keys.TOP_P] ?: 0.9f,
            chunkSize = prefs[Keys.CHUNK_SIZE] ?: 480,
            chunkOverlap = prefs[Keys.CHUNK_OVERLAP] ?: 96,
            trainingEpochs = prefs[Keys.TRAINING_EPOCHS] ?: 5
        )
    }

    suspend fun setLinkedFolder(uri: String?, name: String?) {
        context.dataStore.edit { prefs ->
            if (uri == null) {
                prefs.remove(Keys.LINKED_FOLDER_URI)
                prefs.remove(Keys.LINKED_FOLDER_NAME)
            } else {
                prefs[Keys.LINKED_FOLDER_URI] = uri
                prefs[Keys.LINKED_FOLDER_NAME] = name ?: "Pasta vinculada"
            }
        }
    }

    suspend fun setActiveModel(path: String?, backend: String? = null) {
        context.dataStore.edit { prefs ->
            if (path == null) prefs.remove(Keys.ACTIVE_MODEL_PATH)
            else prefs[Keys.ACTIVE_MODEL_PATH] = path
            if (backend != null) prefs[Keys.ACTIVE_BACKEND] = backend
        }
    }

    suspend fun setActiveBackend(backend: String) {
        context.dataStore.edit { it[Keys.ACTIVE_BACKEND] = backend }
    }

    suspend fun setStrictOfflineMode(enabled: Boolean) {
        context.dataStore.edit { it[Keys.STRICT_OFFLINE] = enabled }
    }

    suspend fun setUseTrainedContext(enabled: Boolean) {
        context.dataStore.edit { it[Keys.USE_TRAINED_CONTEXT] = enabled }
    }

    suspend fun setDarkTheme(enabled: Boolean) {
        context.dataStore.edit { it[Keys.DARK_THEME] = enabled }
    }

    suspend fun updateTrainingConfig(
        persona: String,
        temperature: Float,
        topK: Int,
        topP: Float,
        chunkSize: Int,
        chunkOverlap: Int,
        epochs: Int
    ) {
        context.dataStore.edit { prefs ->
            prefs[Keys.SYSTEM_PERSONA] = persona
            prefs[Keys.TEMPERATURE] = temperature
            prefs[Keys.TOP_K] = topK
            prefs[Keys.TOP_P] = topP
            prefs[Keys.CHUNK_SIZE] = chunkSize
            prefs[Keys.CHUNK_OVERLAP] = chunkOverlap
            prefs[Keys.TRAINING_EPOCHS] = epochs
        }
    }
}
