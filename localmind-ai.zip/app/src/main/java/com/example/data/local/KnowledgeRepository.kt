package com.example.data.local

import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow

class KnowledgeRepository(private val db: NucleoDatabase) {
    private val documentDao = db.documentDao()
    private val chunkDao = db.knowledgeChunkDao()
    private val termDao = db.termWeightDao()
    private val exampleDao = db.trainingExampleDao()
    private val runDao = db.trainingRunDao()
    private val chatDao = db.chatMessageDao()

    val documents: Flow<List<DataDocumentEntity>> = documentDao.observeAll()
    val chunks: Flow<List<KnowledgeChunkEntity>> = chunkDao.observeAll()
    val chunkCount: Flow<Int> = chunkDao.observeCount()
    val vocabSize: Flow<Int> = termDao.observeVocabSize()
    val trainingExamples: Flow<List<TrainingExampleEntity>> = exampleDao.observeAll()
    val trainingRuns: Flow<List<TrainingRunEntity>> = runDao.observeAll()
    val chatMessages: Flow<List<ChatMessageEntity>> = chatDao.observeAll()

    suspend fun getAllDocumentsOnce(): List<DataDocumentEntity> = documentDao.getAllOnce()
    suspend fun getAllChunksOnce(): List<KnowledgeChunkEntity> = chunkDao.getAllOnce()
    suspend fun getAllTermsOnce(): List<TermWeightEntity> = termDao.getAllOnce()
    suspend fun getAllExamplesOnce(): List<TrainingExampleEntity> = exampleDao.getAllOnce()

    suspend fun upsertDocument(doc: DataDocumentEntity): Long {
        val existing = documentDao.findByUri(doc.uriString)
        return if (existing != null) {
            val updated = doc.copy(id = existing.id)
            documentDao.insert(updated)
            existing.id
        } else {
            documentDao.insert(doc)
        }
    }

    suspend fun replaceFolderDocuments(docs: List<DataDocumentEntity>) {
        db.withTransaction {
            documentDao.deleteAllFolderDocs()
            if (docs.isNotEmpty()) {
                documentDao.insertAll(docs)
            }
        }
    }

    suspend fun deleteDocument(id: Long) = documentDao.deleteById(id)

    suspend fun saveTrainingArtifacts(
        chunks: List<KnowledgeChunkEntity>,
        terms: List<TermWeightEntity>,
        docChunkCounts: Map<Long, Int>,
        run: TrainingRunEntity
    ) {
        db.withTransaction {
            chunkDao.clearAll()
            termDao.clearAll()
            if (chunks.isNotEmpty()) chunkDao.insertAll(chunks)
            if (terms.isNotEmpty()) termDao.insertAll(terms)
            docChunkCounts.forEach { (docId, count) ->
                if (docId > 0) {
                    documentDao.updateTrainingStatus(docId, trained = count > 0, chunkCount = count)
                }
            }
            runDao.insert(run)
        }
    }

    suspend fun addTrainingExample(questionPattern: String, expectedContext: String) {
        exampleDao.insert(
            TrainingExampleEntity(
                questionPattern = questionPattern.trim(),
                expectedContext = expectedContext.trim()
            )
        )
    }

    suspend fun deleteTrainingExample(id: Long) = exampleDao.deleteById(id)

    suspend fun addChatMessage(message: ChatMessageEntity): Long = chatDao.insert(message)

    suspend fun clearChat() = chatDao.clearAll()
}
