package com.example.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import com.example.data.local.DataDocumentEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader

data class DetectedModelInFolder(
    val name: String,
    val uriString: String,
    val sizeBytes: Long
)

data class FolderScanResult(
    val folderName: String,
    val documents: List<DataDocumentEntity>,
    val detectedModels: List<DetectedModelInFolder>,
    val skippedBinaryCount: Int
)

class SafFolderScanner(private val context: Context) {

    companion object {
        private val SUPPORTED_TEXT_EXTENSIONS = setOf(
            "txt", "md", "markdown", "csv", "tsv", "json", "jsonl",
            "log", "xml", "yaml", "yml", "ini", "conf", "cfg", "kt", "py", "sql"
        )
        private const val MAX_FILE_BYTES = 1_500_000L // 1.5 MB per text doc
        private const val MAX_FILES_SCAN = 200
        private const val MAX_DEPTH = 4
    }

    suspend fun scanFolder(treeUri: Uri): FolderScanResult = withContext(Dispatchers.IO) {
        val root = DocumentFile.fromTreeUri(context, treeUri)
            ?: throw IllegalStateException("Não foi possível acessar a pasta selecionada.")
        val folderName = root.name ?: "Pasta Local"
        val docs = mutableListOf<DataDocumentEntity>()
        val models = mutableListOf<DetectedModelInFolder>()
        var skipped = 0

        fun walk(dir: DocumentFile, depth: Int) {
            if (depth > MAX_DEPTH || (docs.size + models.size) >= MAX_FILES_SCAN) return
            val children = dir.listFiles()
            for (child in children) {
                if ((docs.size + models.size) >= MAX_FILES_SCAN) break
                if (child.isDirectory) {
                    walk(child, depth + 1)
                } else if (child.isFile) {
                    val name = child.name ?: continue
                    val ext = name.substringAfterLast('.', "").lowercase()
                    val size = child.length()
                    if (ext == "litertlm") {
                        models.add(
                            DetectedModelInFolder(
                                name = name,
                                uriString = child.uri.toString(),
                                sizeBytes = size
                            )
                        )
                        continue
                    }
                    val mime = child.type ?: "text/plain"
                    val isText = ext in SUPPORTED_TEXT_EXTENSIONS || mime.startsWith("text/") || mime == "application/json"
                    if (!isText || size <= 0L || size > MAX_FILE_BYTES) {
                        skipped++
                        continue
                    }
                    val text = readUriText(child.uri)
                    if (text.isNotBlank()) {
                        docs.add(
                            DataDocumentEntity(
                                uriString = child.uri.toString(),
                                fileName = name,
                                mimeType = mime,
                                sizeBytes = size,
                                lastModified = child.lastModified(),
                                contentText = text,
                                sourceType = "FOLDER",
                                isTrained = false,
                                chunkCount = 0
                            )
                        )
                    }
                }
            }
        }

        walk(root, 0)
        FolderScanResult(
            folderName = folderName,
            documents = docs,
            detectedModels = models,
            skippedBinaryCount = skipped
        )
    }

    suspend fun readSingleDocument(uri: Uri): DataDocumentEntity? = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        var fileName = "documento.txt"
        var sizeBytes = 0L
        resolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIdx >= 0) fileName = cursor.getString(nameIdx) ?: fileName
                if (sizeIdx >= 0) sizeBytes = cursor.getLong(sizeIdx)
            }
        }
        val text = readUriText(uri)
        if (text.isBlank()) return@withContext null
        DataDocumentEntity(
            uriString = uri.toString(),
            fileName = fileName,
            mimeType = resolver.getType(uri) ?: "text/plain",
            sizeBytes = if (sizeBytes > 0L) sizeBytes else text.toByteArray().size.toLong(),
            lastModified = System.currentTimeMillis(),
            contentText = text,
            sourceType = "IMPORTED",
            isTrained = false,
            chunkCount = 0
        )
    }

    private fun readUriText(uri: Uri): String {
        return try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                BufferedReader(InputStreamReader(input, Charsets.UTF_8)).use { reader ->
                    val sb = StringBuilder()
                    val buffer = CharArray(8192)
                    var totalRead = 0
                    while (totalRead < MAX_FILE_BYTES) {
                        val count = reader.read(buffer)
                        if (count <= 0) break
                        sb.append(buffer, 0, count)
                        totalRead += count
                    }
                    sb.toString().trim()
                }
            } ?: ""
        } catch (_: Exception) {
            ""
        }
    }
}
