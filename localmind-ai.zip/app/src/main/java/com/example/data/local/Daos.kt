package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface DocumentDao {
    @Query("SELECT * FROM data_documents ORDER BY addedAt DESC")
    fun observeAll(): Flow<List<DataDocumentEntity>>

    @Query("SELECT * FROM data_documents ORDER BY addedAt DESC")
    suspend fun getAllOnce(): List<DataDocumentEntity>

    @Query("SELECT * FROM data_documents WHERE uriString = :uriString LIMIT 1")
    suspend fun findByUri(uriString: String): DataDocumentEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(doc: DataDocumentEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(docs: List<DataDocumentEntity>)

    @Query("DELETE FROM data_documents WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM data_documents WHERE sourceType = 'FOLDER'")
    suspend fun deleteAllFolderDocs()

    @Query("UPDATE data_documents SET isTrained = :trained, chunkCount = :chunkCount WHERE id = :id")
    suspend fun updateTrainingStatus(id: Long, trained: Boolean, chunkCount: Int)
}

@Dao
interface KnowledgeChunkDao {
    @Query("SELECT * FROM knowledge_chunks ORDER BY documentId, chunkIndex")
    fun observeAll(): Flow<List<KnowledgeChunkEntity>>

    @Query("SELECT * FROM knowledge_chunks")
    suspend fun getAllOnce(): List<KnowledgeChunkEntity>

    @Query("SELECT COUNT(*) FROM knowledge_chunks")
    fun observeCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(chunks: List<KnowledgeChunkEntity>)

    @Query("DELETE FROM knowledge_chunks")
    suspend fun clearAll()
}

@Dao
interface TermWeightDao {
    @Query("SELECT * FROM term_weights")
    suspend fun getAllOnce(): List<TermWeightEntity>

    @Query("SELECT COUNT(*) FROM term_weights")
    fun observeVocabSize(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(terms: List<TermWeightEntity>)

    @Query("DELETE FROM term_weights")
    suspend fun clearAll()
}

@Dao
interface TrainingExampleDao {
    @Query("SELECT * FROM training_examples ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<TrainingExampleEntity>>

    @Query("SELECT * FROM training_examples ORDER BY createdAt DESC")
    suspend fun getAllOnce(): List<TrainingExampleEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(example: TrainingExampleEntity)

    @Query("DELETE FROM training_examples WHERE id = :id")
    suspend fun deleteById(id: Long)
}

@Dao
interface TrainingRunDao {
    @Query("SELECT * FROM training_runs ORDER BY timestamp DESC")
    fun observeAll(): Flow<List<TrainingRunEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(run: TrainingRunEntity)

    @Query("DELETE FROM training_runs")
    suspend fun clearAll()
}

@Dao
interface ChatMessageDao {
    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC, id ASC")
    fun observeAll(): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(message: ChatMessageEntity): Long

    @Query("DELETE FROM chat_messages")
    suspend fun clearAll()
}
