package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        DataDocumentEntity::class,
        KnowledgeChunkEntity::class,
        TermWeightEntity::class,
        TrainingExampleEntity::class,
        TrainingRunEntity::class,
        ChatMessageEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class NucleoDatabase : RoomDatabase() {
    abstract fun documentDao(): DocumentDao
    abstract fun knowledgeChunkDao(): KnowledgeChunkDao
    abstract fun termWeightDao(): TermWeightDao
    abstract fun trainingExampleDao(): TrainingExampleDao
    abstract fun trainingRunDao(): TrainingRunDao
    abstract fun chatMessageDao(): ChatMessageDao

    companion object {
        @Volatile
        private var INSTANCE: NucleoDatabase? = null

        fun getInstance(context: Context): NucleoDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    NucleoDatabase::class.java,
                    "nucleo_ia_local.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
