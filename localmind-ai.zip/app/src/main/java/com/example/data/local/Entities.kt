package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "data_documents")
data class DataDocumentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val uriString: String,
    val fileName: String,
    val mimeType: String,
    val sizeBytes: Long,
    val lastModified: Long,
    val contentText: String,
    val sourceType: String, // "FOLDER", "IMPORTED", "NOTE"
    val isTrained: Boolean = false,
    val chunkCount: Int = 0,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "knowledge_chunks")
data class KnowledgeChunkEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val documentId: Long,
    val documentName: String,
    val chunkIndex: Int,
    val text: String,
    val keywords: String,
    val tokenCount: Int,
    val weightBoost: Float = 1.0f,
    val epochTrainedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "term_weights")
data class TermWeightEntity(
    @PrimaryKey val term: String,
    val idf: Float,
    val docFreq: Int,
    val totalFreq: Int,
    val learnedWeight: Float
)

@Entity(tableName = "training_examples")
data class TrainingExampleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val questionPattern: String,
    val expectedContext: String,
    val priorityWeight: Float = 2.0f,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "training_runs")
data class TrainingRunEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val documentsCount: Int,
    val chunksCount: Int,
    val vocabSize: Int,
    val epochs: Int,
    val chunkSize: Int,
    val overlap: Int,
    val finalLoss: Float,
    val retrievalScore: Float,
    val durationMs: Long,
    val lossCurveCsv: String
)

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String, // "USER" or "ASSISTANT"
    val content: String,
    val sourcesCsv: String = "",
    val inferenceMode: String = "",
    val latencyMs: Long = 0,
    val timestamp: Long = System.currentTimeMillis()
)
