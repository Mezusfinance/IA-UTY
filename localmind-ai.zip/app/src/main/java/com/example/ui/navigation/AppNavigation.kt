package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.FolderSpecial
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.ui.graphics.vector.ImageVector
import kotlinx.serialization.Serializable

@Serializable
sealed interface AppRoute {
    @Serializable
    data object Chat : AppRoute

    @Serializable
    data object Folder : AppRoute

    @Serializable
    data object Train : AppRoute

    @Serializable
    data object Engine : AppRoute
}

data class NavTabItem(
    val route: AppRoute,
    val label: String,
    val testTag: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

val APP_TABS = listOf(
    NavTabItem(
        route = AppRoute.Chat,
        label = "Chat",
        testTag = "nav_tab_chat",
        selectedIcon = Icons.Filled.ChatBubble,
        unselectedIcon = Icons.Outlined.ChatBubbleOutline
    ),
    NavTabItem(
        route = AppRoute.Folder,
        label = "Pasta",
        testTag = "nav_tab_folder",
        selectedIcon = Icons.Filled.FolderSpecial,
        unselectedIcon = Icons.Outlined.Folder
    ),
    NavTabItem(
        route = AppRoute.Train,
        label = "Treinar",
        testTag = "nav_tab_train",
        selectedIcon = Icons.Filled.Psychology,
        unselectedIcon = Icons.Outlined.Psychology
    ),
    NavTabItem(
        route = AppRoute.Engine,
        label = "Motor",
        testTag = "nav_tab_engine",
        selectedIcon = Icons.Filled.Memory,
        unselectedIcon = Icons.Outlined.Memory
    )
)
