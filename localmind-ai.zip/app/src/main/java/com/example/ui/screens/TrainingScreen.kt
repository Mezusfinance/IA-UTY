package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ai.TrainingProgress
import com.example.data.local.AppSettings
import com.example.data.local.TrainingExampleEntity
import com.example.data.local.TrainingRunEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TrainingScreen(
    settings: AppSettings,
    documentsCount: Int,
    trainedChunkCount: Int,
    vocabSize: Int,
    trainingProgress: TrainingProgress,
    examples: List<TrainingExampleEntity>,
    trainingRuns: List<TrainingRunEntity>,
    onUpdateHyperparams: (String, Float, Int, Float, Int, Int, Int) -> Unit,
    onStartTraining: () -> Unit,
    onAddExample: (String, String) -> Unit,
    onDeleteExample: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    var persona by remember { mutableStateOf(settings.systemPersona) }
    var temperature by remember { mutableFloatStateOf(settings.temperature) }
    var topK by remember { mutableIntStateOf(settings.topK) }
    var topP by remember { mutableFloatStateOf(settings.topP) }
    var chunkSize by remember { mutableIntStateOf(settings.chunkSize) }
    var overlap by remember { mutableIntStateOf(settings.chunkOverlap) }
    var epochs by remember { mutableIntStateOf(settings.trainingEpochs) }

    LaunchedEffect(settings) {
        persona = settings.systemPersona
        temperature = settings.temperature
        topK = settings.topK
        topP = settings.topP
        chunkSize = settings.chunkSize
        overlap = settings.chunkOverlap
        epochs = settings.trainingEpochs
    }

    var showAddExampleDialog by remember { mutableStateOf(false) }

    val activeLossCurve = remember(trainingProgress.lossCurve, trainingRuns) {
        if (trainingProgress.lossCurve.isNotEmpty()) {
            trainingProgress.lossCurve
        } else {
            trainingRuns.firstOrNull()?.lossCurveCsv
                ?.split(',')
                ?.mapNotNull { it.trim().toFloatOrNull() }
                ?: emptyList()
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header Hero Card
        item {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.outline.copy(alpha = 0.45f),
                        MaterialTheme.shapes.large
                    )
            ) {
                Box {
                    Image(
                        painter = painterResource(id = R.drawable.img_neural_core_banner),
                        contentDescription = "Estúdio de treinamento local",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        Color.Transparent,
                                        MaterialTheme.colorScheme.surfaceContainer
                                    )
                                )
                            )
                    )
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "Estúdio de Treinamento",
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Indexação semântica multi-época, pesos BM25/TF-IDF e adaptação de regras no dispositivo.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Telemetry Metrics Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MetricPill(
                        label = "ARQUIVOS",
                        value = "$documentsCount",
                        modifier = Modifier.weight(1f)
                    )
                    MetricPill(
                        label = "FRAGMENTOS",
                        value = "$trainedChunkCount",
                        modifier = Modifier.weight(1f)
                    )
                    MetricPill(
                        label = "VOCABULÁRIO",
                        value = "$vocabSize",
                        modifier = Modifier.weight(1f)
                    )
                }

                // Start Training CTA & Progress
                Column(modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 16.dp)) {
                    if (trainingProgress.isRunning || trainingProgress.stageLabel.isNotEmpty()) {
                        Text(
                            text = trainingProgress.stageLabel,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { trainingProgress.progress },
                            color = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(4.dp))
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    Button(
                        onClick = {
                            onUpdateHyperparams(persona, temperature, topK, topP, chunkSize, overlap, epochs)
                            onStartTraining()
                        },
                        enabled = !trainingProgress.isRunning && (documentsCount > 0 || examples.isNotEmpty()),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .minimumInteractiveComponentSize()
                            .testTag("train_start_button")
                    ) {
                        Icon(
                            imageVector = if (trainingProgress.isRunning) Icons.Filled.Psychology else Icons.Filled.PlayArrow,
                            contentDescription = null
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (trainingProgress.isRunning) {
                                "Treinando Época ${trainingProgress.currentEpoch}/${trainingProgress.totalEpochs}…"
                            } else {
                                "Treinar IA com Dados da Pasta"
                            }
                        )
                    }
                }
            }
        }

        // Loss Curve Chart
        if (activeLossCurve.isNotEmpty()) {
            item {
                Card(
                    shape = MaterialTheme.shapes.medium,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            1.dp,
                            MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                            MaterialTheme.shapes.medium
                        )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Convergência de Perda Contrastiva",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Loss final: ${String.format(Locale.US, "%.3f", activeLossCurve.last())}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        LossCurveCanvas(
                            values = activeLossCurve,
                            lineColor = MaterialTheme.colorScheme.primary,
                            gridColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp)
                        )
                    }
                }
            }
        }

        // Custom Q&A / Behavioral Rules
        item {
            Card(
                shape = MaterialTheme.shapes.medium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                        MaterialTheme.shapes.medium
                    )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Regras & Pares Q&A Aprendidos",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Ensine respostas exatas, termos técnicos ou instruções que a IA deve priorizar.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        OutlinedButton(
                            onClick = { showAddExampleDialog = true },
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("train_add_rule_button")
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Regra")
                        }
                    }

                    if (examples.isEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Nenhuma regra personalizada adicionada.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        Spacer(modifier = Modifier.height(10.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            examples.forEach { ex ->
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceContainerHigh,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "Gatilho: ${ex.questionPattern}",
                                                style = MaterialTheme.typography.labelMedium,
                                                color = MaterialTheme.colorScheme.secondary
                                            )
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = ex.expectedContext,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                        }
                                        IconButton(
                                            onClick = { onDeleteExample(ex.id) },
                                            modifier = Modifier.minimumInteractiveComponentSize()
                                        ) {
                                            Icon(
                                                imageVector = Icons.Filled.DeleteOutline,
                                                contentDescription = "Remover regra",
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Hyperparameters & Persona Card
        item {
            Card(
                shape = MaterialTheme.shapes.medium,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                        MaterialTheme.shapes.medium
                    )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.Tune,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.tertiary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Parâmetros de Treino & Amostragem",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Text(
                        text = "Tamanho do fragmento (caracteres)",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(256, 480, 768, 1024).forEach { size ->
                            FilterChip(
                                selected = chunkSize == size,
                                onClick = { chunkSize = size },
                                label = { Text("$size") }
                            )
                        }
                    }

                    Text(
                        text = "Sobreposição entre fragmentos",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(48, 96, 160).forEach { ov ->
                            FilterChip(
                                selected = overlap == ov,
                                onClick = { overlap = ov },
                                label = { Text("$ov") }
                            )
                        }
                    }

                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Épocas de refinamento", style = MaterialTheme.typography.labelMedium)
                            Text("$epochs épocas", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                        }
                        Slider(
                            value = epochs.toFloat(),
                            onValueChange = { epochs = it.roundToInt().coerceIn(1, 10) },
                            valueRange = 1f..10f,
                            steps = 8
                        )
                    }

                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Temperatura (criatividade LLM)", style = MaterialTheme.typography.labelMedium)
                            Text(
                                String.format(Locale.US, "%.2f", temperature),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Slider(
                            value = temperature,
                            onValueChange = { temperature = it },
                            valueRange = 0.1f..1.2f
                        )
                    }

                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Top-K / Top-P", style = MaterialTheme.typography.labelMedium)
                            Text(
                                "K=$topK • P=${String.format(Locale.US, "%.2f", topP)}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Slider(
                            value = topK.toFloat(),
                            onValueChange = { topK = it.roundToInt().coerceIn(5, 40) },
                            valueRange = 5f..40f
                        )
                    }

                    OutlinedTextField(
                        value = persona,
                        onValueChange = { persona = it },
                        label = { Text("Persona / Instrução do Sistema") },
                        minLines = 3,
                        maxLines = 5,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedButton(
                        onClick = {
                            onUpdateHyperparams(persona, temperature, topK, topP, chunkSize, overlap, epochs)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .minimumInteractiveComponentSize()
                            .testTag("train_save_config_button")
                    ) {
                        Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Salvar Configurações")
                    }
                }
            }
        }

        // Training History
        if (trainingRuns.isNotEmpty()) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.History,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Histórico de Treinamentos",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
            }
            items(trainingRuns, key = { it.id }) { run ->
                val dateLabel = remember(run.timestamp) {
                    SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(run.timestamp))
                }
                Surface(
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            1.dp,
                            MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                            MaterialTheme.shapes.medium
                        )
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "$dateLabel • ${run.epochs} épocas",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "${run.documentsCount} docs • ${run.chunksCount} frag. • ${run.vocabSize} termos",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "${(run.retrievalScore * 100).roundToInt()}% acerto",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "${run.durationMs} ms",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }

    if (showAddExampleDialog) {
        AddTrainingRuleDialog(
            onDismiss = { showAddExampleDialog = false },
            onSave = { q, a ->
                onAddExample(q, a)
                showAddExampleDialog = false
            }
        )
    }
}

@Composable
private fun MetricPill(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun LossCurveCanvas(
    values: List<Float>,
    lineColor: Color,
    gridColor: Color,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        if (values.isEmpty()) return@Canvas
        val w = size.width
        val h = size.height
        val pad = 12f

        // Horizontal reference lines
        for (i in 0..2) {
            val y = pad + (h - 2 * pad) * (i / 2f)
            drawLine(
                color = gridColor,
                start = Offset(pad, y),
                end = Offset(w - pad, y),
                strokeWidth = 1.5f
            )
        }

        val maxVal = (values.maxOrNull() ?: 1f).coerceAtLeast(0.1f)
        val minVal = (values.minOrNull() ?: 0f)
        val range = (maxVal - minVal).coerceAtLeast(0.05f)

        val points = values.mapIndexed { idx, v ->
            val x = if (values.size == 1) w / 2f else pad + (w - 2 * pad) * (idx.toFloat() / (values.size - 1).toFloat())
            val norm = (v - minVal) / range
            val y = (h - pad) - norm * (h - 2 * pad)
            Offset(x, y)
        }

        if (points.size >= 2) {
            val path = Path().apply {
                moveTo(points.first().x, points.first().y)
                for (i in 1 until points.size) {
                    lineTo(points[i].x, points[i].y)
                }
            }
            drawPath(
                path = path,
                color = lineColor,
                style = Stroke(width = 5f, cap = StrokeCap.Round)
            )
        }

        points.forEach { pt ->
            drawCircle(
                color = lineColor,
                radius = 7f,
                center = pt
            )
        }
    }
}

@Composable
private fun AddTrainingRuleDialog(
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit
) {
    var question by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nova Regra de Aprendizado") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = question,
                    onValueChange = { question = it },
                    label = { Text("Quando perguntarem sobre…") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("rule_question_input")
                )
                OutlinedTextField(
                    value = answer,
                    onValueChange = { answer = it },
                    label = { Text("Resposta ou diretriz esperada") },
                    minLines = 3,
                    maxLines = 6,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("rule_answer_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(question, answer) },
                enabled = question.isNotBlank() && answer.isNotBlank(),
                modifier = Modifier.testTag("rule_save_button")
            ) {
                Text("Adicionar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}
