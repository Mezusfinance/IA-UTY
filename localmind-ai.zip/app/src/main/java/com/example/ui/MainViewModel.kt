package com.example.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.CatalogModelSpec
import com.example.ai.DeviceHardwareInfo
import com.example.ai.EngineStatus
import com.example.ai.InstalledModelFile
import com.example.ai.LiteRtEngineManager
import com.example.ai.LocalKnowledgeTrainer
import com.example.ai.LocalRetriever
import com.example.ai.ModelStorageManager
import com.example.ai.ModelTransferState
import com.example.ai.TrainingProgress
import com.example.data.DetectedModelInFolder as ScannerDetectedModel
import com.example.data.SafFolderScanner
import com.example.data.local.AppSettings
import com.example.data.local.ChatMessageEntity
import com.example.data.local.DataDocumentEntity
import com.example.data.local.KnowledgeRepository
import com.example.data.local.NucleoDatabase
import com.example.data.local.PreferencesStore
import com.example.data.local.TrainingExampleEntity
import com.example.data.local.TrainingRunEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val database = NucleoDatabase.getInstance(app)
    private val repository = KnowledgeRepository(database)
    private val prefs = PreferencesStore(app)
    private val folderScanner = SafFolderScanner(app)
    private val trainer = LocalKnowledgeTrainer()
    private val retriever = LocalRetriever()
    val engineManager = LiteRtEngineManager(app)
    val modelStorage = ModelStorageManager(app)

    val settings: StateFlow<AppSettings> = prefs.settingsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = AppSettings()
    )

    val documents: StateFlow<List<DataDocumentEntity>> = repository.documents.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val trainedChunkCount: StateFlow<Int> = repository.chunkCount.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0
    )

    val vocabSize: StateFlow<Int> = repository.vocabSize.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0
    )

    val trainingExamples: StateFlow<List<TrainingExampleEntity>> = repository.trainingExamples.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val trainingRuns: StateFlow<List<TrainingRunEntity>> = repository.trainingRuns.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val chatMessages: StateFlow<List<ChatMessageEntity>> = repository.chatMessages.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val engineStatus: StateFlow<EngineStatus> = engineManager.status
    val isGenerating: StateFlow<Boolean> = engineManager.isGenerating
    val streamingReply: StateFlow<String> = engineManager.streamingReply
    val transferState: StateFlow<ModelTransferState> = modelStorage.transferState

    private val _trainingProgress = MutableStateFlow(TrainingProgress())
    val trainingProgress: StateFlow<TrainingProgress> = _trainingProgress.asStateFlow()

    private val _installedModels = MutableStateFlow<List<InstalledModelFile>>(emptyList())
    val installedModels: StateFlow<List<InstalledModelFile>> = _installedModels.asStateFlow()

    private val _detectedModelsInFolder = MutableStateFlow<List<ScannerDetectedModel>>(emptyList())
    val detectedModelsInFolder: StateFlow<List<ScannerDetectedModel>> = _detectedModelsInFolder.asStateFlow()

    private val _hardwareInfo = MutableStateFlow(modelStorage.getHardwareInfo())
    val hardwareInfo: StateFlow<DeviceHardwareInfo> = _hardwareInfo.asStateFlow()

    private val _isScanningFolder = MutableStateFlow(false)
    val isScanningFolder: StateFlow<Boolean> = _isScanningFolder.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    init {
        refreshInstalledModels()
        viewModelScope.launch {
            val currentSettings = prefs.settingsFlow.first()
            val savedPath = currentSettings.activeModelPath
            if (!savedPath.isNullOrBlank() && java.io.File(savedPath).exists()) {
                val examples = repository.getAllExamplesOnce()
                val sysInstruction = retriever.buildSystemInstruction(currentSettings.systemPersona, examples)
                engineManager.loadModel(
                    modelPath = savedPath,
                    backendName = currentSettings.activeBackend,
                    systemInstruction = sysInstruction,
                    topK = currentSettings.topK,
                    topP = currentSettings.topP.toDouble(),
                    temperature = currentSettings.temperature.toDouble()
                )
            }
        }
    }

    fun clearStatusBanner() {
        _statusBanner.value = null
    }

    fun refreshHardwareAndModels() {
        _hardwareInfo.value = modelStorage.getHardwareInfo()
        refreshInstalledModels()
    }

    private fun refreshInstalledModels() {
        viewModelScope.launch(Dispatchers.IO) {
            _installedModels.value = modelStorage.listInstalledModels()
        }
    }

    fun linkFolder(treeUri: Uri) {
        viewModelScope.launch {
            try {
                val app = getApplication<Application>()
                val takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION
                app.contentResolver.takePersistableUriPermission(treeUri, takeFlags)
            } catch (_: SecurityException) {
                // Some providers issue non-persistable grants; still proceed with immediate scan
            }
            syncFolderUri(treeUri)
        }
    }

    fun resyncLinkedFolder() {
        val uriStr = settings.value.linkedFolderUri
        if (uriStr.isNullOrBlank()) {
            _statusBanner.value = "Nenhuma pasta vinculada ainda."
            return
        }
        syncFolderUri(Uri.parse(uriStr))
    }

    private fun syncFolderUri(treeUri: Uri) {
        viewModelScope.launch {
            _isScanningFolder.value = true
            try {
                val result = folderScanner.scanFolder(treeUri)
                prefs.setLinkedFolder(treeUri.toString(), result.folderName)
                repository.replaceFolderDocuments(result.documents)
                _detectedModelsInFolder.value = result.detectedModels
                val modelNotice = if (result.detectedModels.isNotEmpty()) {
                    " • ${result.detectedModels.size} modelo(s) .litertlm detectado(s)"
                } else ""
                _statusBanner.value = "Pasta \"${result.folderName}\" sincronizada: ${result.documents.size} arquivo(s) de texto$modelNotice."
            } catch (e: Exception) {
                _statusBanner.value = "Erro ao ler pasta: ${e.message}"
            } finally {
                _isScanningFolder.value = false
            }
        }
    }

    fun unlinkFolder() {
        viewModelScope.launch {
            prefs.setLinkedFolder(null, null)
            repository.replaceFolderDocuments(emptyList())
            _detectedModelsInFolder.value = emptyList()
            _statusBanner.value = "Pasta desvinculada."
        }
    }

    fun importDocumentFile(uri: Uri) {
        viewModelScope.launch {
            val doc = folderScanner.readSingleDocument(uri)
            if (doc != null) {
                repository.upsertDocument(doc)
                _statusBanner.value = "Arquivo \"${doc.fileName}\" adicionado à base local."
            } else {
                _statusBanner.value = "Não foi possível extrair texto legível deste arquivo."
            }
        }
    }

    fun createLocalNote(title: String, body: String) {
        val cleanTitle = title.trim().ifEmpty { "nota_local.txt" }
        val fileName = if (cleanTitle.contains('.')) cleanTitle else "$cleanTitle.md"
        val cleanBody = body.trim()
        if (cleanBody.isEmpty()) return

        viewModelScope.launch {
            val doc = DataDocumentEntity(
                uriString = "local://note/${System.currentTimeMillis()}",
                fileName = fileName,
                mimeType = "text/markdown",
                sizeBytes = cleanBody.toByteArray().size.toLong(),
                lastModified = System.currentTimeMillis(),
                contentText = cleanBody,
                sourceType = "NOTE",
                isTrained = false,
                chunkCount = 0
            )
            repository.upsertDocument(doc)
            _statusBanner.value = "Nota \"$fileName\" salva no dispositivo."
        }
    }

    fun deleteDocument(id: Long) {
        viewModelScope.launch {
            repository.deleteDocument(id)
        }
    }

    fun addTrainingExample(question: String, expected: String) {
        if (question.isBlank() || expected.isBlank()) return
        viewModelScope.launch {
            repository.addTrainingExample(question, expected)
            _statusBanner.value = "Regra de aprendizado adicionada."
        }
    }

    fun deleteTrainingExample(id: Long) {
        viewModelScope.launch {
            repository.deleteTrainingExample(id)
        }
    }

    fun updateHyperparameters(
        persona: String,
        temperature: Float,
        topK: Int,
        topP: Float,
        chunkSize: Int,
        overlap: Int,
        epochs: Int
    ) {
        viewModelScope.launch {
            prefs.updateTrainingConfig(
                persona = persona,
                temperature = temperature,
                topK = topK,
                topP = topP,
                chunkSize = chunkSize,
                chunkOverlap = overlap,
                epochs = epochs
            )
        }
    }

    fun startTraining() {
        if (_trainingProgress.value.isRunning) return
        viewModelScope.launch {
            val docs = repository.getAllDocumentsOnce()
            val examples = repository.getAllExamplesOnce()
            val cfg = settings.value
            try {
                val output = trainer.train(
                    documents = docs,
                    examples = examples,
                    chunkSize = cfg.chunkSize,
                    overlap = cfg.chunkOverlap,
                    epochs = cfg.trainingEpochs
                ) { progress ->
                    _trainingProgress.value = progress
                }
                repository.saveTrainingArtifacts(
                    chunks = output.chunks,
                    terms = output.terms,
                    docChunkCounts = output.docChunkCounts,
                    run = output.run
                )
                // If neural engine is loaded, refresh its system instruction with new learned rules
                if (engineStatus.value is EngineStatus.Ready) {
                    val sysInstruction = retriever.buildSystemInstruction(cfg.systemPersona, examples)
                    engineManager.resetConversation(
                        systemInstruction = sysInstruction,
                        topK = cfg.topK,
                        topP = cfg.topP.toDouble(),
                        temperature = cfg.temperature.toDouble()
                    )
                }
                _statusBanner.value = "Treinamento finalizado: ${output.chunks.size} fragmentos e ${output.terms.size} termos indexados."
            } catch (e: Exception) {
                _trainingProgress.value = TrainingProgress(
                    isRunning = false,
                    stageLabel = e.message ?: "Erro no treinamento"
                )
                _statusBanner.value = e.message ?: "Não foi possível treinar."
            }
        }
    }

    fun sendUserMessage(text: String) {
        val cleanText = text.trim()
        if (cleanText.isEmpty() || isGenerating.value) return

        viewModelScope.launch {
            val cfg = settings.value
            val startMs = System.currentTimeMillis()
            repository.addChatMessage(
                ChatMessageEntity(
                    role = "USER",
                    content = cleanText
                )
            )

            val chunks = if (cfg.useTrainedContext) repository.getAllChunksOnce() else emptyList()
            val terms = if (cfg.useTrainedContext) repository.getAllTermsOnce() else emptyList()
            val examples = if (cfg.useTrainedContext) repository.getAllExamplesOnce() else emptyList()

            val retrieved = if (cfg.useTrainedContext) {
                retriever.retrieve(cleanText, chunks, terms, topK = 4)
            } else emptyList()

            val sourcesCsv = retrieved.joinToString(" | ") {
                "${it.chunk.documentName} (${(it.score * 100).toInt()}%)"
            }

            val currentEngine = engineStatus.value
            if (currentEngine is EngineStatus.Ready) {
                val augmentedPrompt = if (cfg.useTrainedContext) {
                    retriever.buildAugmentedPrompt(cleanText, retrieved, examples)
                } else {
                    cleanText
                }
                engineManager.generateReply(augmentedPrompt) { result ->
                    viewModelScope.launch {
                        val elapsed = System.currentTimeMillis() - startMs
                        val replyText = result.getOrElse { err ->
                            "Erro na inferência LiteRT-LM: ${err.message}"
                        }.ifBlank { "Sem resposta gerada pelo modelo." }
                        repository.addChatMessage(
                            ChatMessageEntity(
                                role = "ASSISTANT",
                                content = replyText,
                                sourcesCsv = sourcesCsv,
                                inferenceMode = "LiteRT-LM ${currentEngine.backendName}",
                                latencyMs = elapsed
                            )
                        )
                    }
                }
            } else {
                val extractiveReply = retriever.synthesizeExtractiveReply(
                    query = cleanText,
                    retrieved = retrieved,
                    totalTrainedChunks = chunks.size
                )
                val elapsed = System.currentTimeMillis() - startMs
                repository.addChatMessage(
                    ChatMessageEntity(
                        role = "ASSISTANT",
                        content = extractiveReply,
                        sourcesCsv = sourcesCsv,
                        inferenceMode = "Extrativo Local (Sem .litertlm)",
                        latencyMs = elapsed
                    )
                )
            }
        }
    }

    fun stopGeneration() {
        engineManager.stopGeneration()
    }

    fun startNewChatSession() {
        viewModelScope.launch {
            repository.clearChat()
            val cfg = settings.value
            if (engineStatus.value is EngineStatus.Ready) {
                val examples = repository.getAllExamplesOnce()
                val sysInstruction = retriever.buildSystemInstruction(cfg.systemPersona, examples)
                engineManager.resetConversation(
                    systemInstruction = sysInstruction,
                    topK = cfg.topK,
                    topP = cfg.topP.toDouble(),
                    temperature = cfg.temperature.toDouble()
                )
            }
        }
    }

    fun toggleUseTrainedContext(enabled: Boolean) {
        viewModelScope.launch { prefs.setUseTrainedContext(enabled) }
    }

    fun toggleStrictOffline(enabled: Boolean) {
        viewModelScope.launch { prefs.setStrictOfflineMode(enabled) }
    }

    fun toggleDarkTheme(enabled: Boolean) {
        viewModelScope.launch { prefs.setDarkTheme(enabled) }
    }

    fun setPreferredBackend(backend: String) {
        viewModelScope.launch {
            prefs.setActiveBackend(backend)
            val currentPath = settings.value.activeModelPath
            if (!currentPath.isNullOrBlank() && engineStatus.value is EngineStatus.Ready) {
                loadLocalModel(currentPath, backend)
            }
        }
    }

    fun loadLocalModel(path: String, backend: String = settings.value.activeBackend) {
        viewModelScope.launch {
            prefs.setActiveModel(path, backend)
            val cfg = settings.value
            val examples = repository.getAllExamplesOnce()
            val sysInstruction = retriever.buildSystemInstruction(cfg.systemPersona, examples)
            engineManager.loadModel(
                modelPath = path,
                backendName = backend,
                systemInstruction = sysInstruction,
                topK = cfg.topK,
                topP = cfg.topP.toDouble(),
                temperature = cfg.temperature.toDouble()
            )
        }
    }

    fun unloadModel() {
        viewModelScope.launch {
            prefs.setActiveModel(null)
            engineManager.unloadModel()
        }
    }

    fun deleteInstalledModel(path: String) {
        viewModelScope.launch {
            if (settings.value.activeModelPath == path) {
                prefs.setActiveModel(null)
                engineManager.unloadModel()
            }
            modelStorage.deleteModel(path)
            refreshInstalledModels()
            _statusBanner.value = "Modelo removido do armazenamento interno."
        }
    }

    fun importModelFile(uri: Uri, autoLoad: Boolean = true) {
        viewModelScope.launch {
            val result = modelStorage.importModelFromUri(uri)
            refreshInstalledModels()
            result.onSuccess { model ->
                _statusBanner.value = "Modelo \"${model.name}\" importado para uso 100% off-line."
                if (autoLoad) {
                    loadLocalModel(model.path, settings.value.activeBackend)
                }
            }.onFailure { err ->
                _statusBanner.value = err.message ?: "Falha ao importar arquivo .litertlm."
            }
        }
    }

    fun downloadCatalogModel(spec: CatalogModelSpec) {
        if (settings.value.strictOfflineMode) {
            _statusBanner.value = "Modo 100% Off-line está ativo. Desative-o temporariamente nesta tela para baixar o modelo 1x."
            return
        }
        viewModelScope.launch {
            val result = modelStorage.downloadCatalogModel(spec)
            refreshInstalledModels()
            result.onSuccess { model ->
                _statusBanner.value = "Modelo \"${model.name}\" baixado! Agora você pode ativar o Modo 100% Off-line."
                loadLocalModel(model.path, settings.value.activeBackend)
            }.onFailure { err ->
                _statusBanner.value = err.message ?: "Não foi possível baixar o modelo."
            }
        }
    }

    fun cancelModelTransfer() {
        modelStorage.cancelTransfer()
    }

    override fun onCleared() {
        engineManager.shutdown()
        super.onCleared()
    }
}
