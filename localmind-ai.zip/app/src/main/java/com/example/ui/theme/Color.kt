package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Obsidian Neural Lab — Dark Palette (Primary Atmospheric Theme)
val ObsidianVoid = Color(0xFF0B0F14)
val ObsidianSurface = Color(0xFF121820)
val ObsidianSurfaceContainer = Color(0xFF18212C)
val ObsidianSurfaceHigh = Color(0xFF202B38)
val ObsidianOutline = Color(0xFF2E3D4F)

val MintPhosphor = Color(0xFF2EF2A8)
val OnMintPhosphor = Color(0xFF003823)
val MintContainerDark = Color(0xFF0B4A34)
val OnMintContainerDark = Color(0xFF8CFFCB)

val AmberEpoch = Color(0xFFFFB84D)
val OnAmberEpoch = Color(0xFF452800)
val AmberContainerDark = Color(0xFF4F3208)
val OnAmberContainerDark = Color(0xFFFFDDA8)

val CyanMatrix = Color(0xFF5CE1E6)
val OnCyanMatrix = Color(0xFF00363A)
val CyanContainerDark = Color(0xFF0D454B)
val OnCyanContainerDark = Color(0xFFA8F7FA)

val TextPrimaryDark = Color(0xFFEDF2F7)
val TextSecondaryDark = Color(0xFF99AABB)
val CoralErrorDark = Color(0xFFFF6B6B)
val OnCoralErrorDark = Color(0xFF4C0007)
val CoralContainerDark = Color(0xFF5C151B)
val OnCoralContainerDark = Color(0xFFFFDAD9)

// Crisp Technical Paper — Light Palette
val PaperBackground = Color(0xFFF4F7F6)
val PaperSurface = Color(0xFFFFFFFF)
val PaperSurfaceContainer = Color(0xFFEAF0EE)
val PaperSurfaceHigh = Color(0xFFDDE7E4)
val PaperOutline = Color(0xFFC2D1CC)

val EmeraldPrimaryLight = Color(0xFF007A53)
val OnEmeraldLight = Color(0xFFFFFFFF)
val EmeraldContainerLight = Color(0xFFB5F5D9)
val OnEmeraldContainerLight = Color(0xFF002114)

val CopperSecondaryLight = Color(0xFF9E5800)
val OnCopperLight = Color(0xFFFFFFFF)
val CopperContainerLight = Color(0xFFFFDDB8)
val OnCopperContainerLight = Color(0xFF331B00)

val TealTertiaryLight = Color(0xFF006874)
val OnTealLight = Color(0xFFFFFFFF)
val TealContainerLight = Color(0xFFA4F0FA)
val OnTealContainerLight = Color(0xFF001F24)

val TextPrimaryLight = Color(0xFF10181F)
val TextSecondaryLight = Color(0xFF4D5F6E)
val CoralErrorLight = Color(0xFFBA1A1A)
