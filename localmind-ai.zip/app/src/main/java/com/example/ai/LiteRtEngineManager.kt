package com.example.ai

import android.app.Application
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.util.concurrent.Executors
import kotlin.coroutines.cancellation.CancellationException

sealed interface EngineStatus {
    data object Unloaded : EngineStatus
    data class Loading(val modelName: String, val backendName: String) : EngineStatus
    data class Ready(val modelPath: String, val modelName: String, val backendName: String) : EngineStatus
    data class Error(val message: String) : EngineStatus
}

class LiteRtEngineManager(private val app: Application) {

    // Single-thread executor exclusively owns Engine & Conversation lifecycle
    private val executor = Executors.newSingleThreadExecutor()
    private val scope = CoroutineScope(SupervisorJob() + executor.asCoroutineDispatcher())
    private val mutex = Mutex()

    private var engine: Engine? = null
    private var conversation: Conversation? = null
    private var loadedBackendName: String = "CPU"

    private val _status = MutableStateFlow<EngineStatus>(EngineStatus.Unloaded)
    val status: StateFlow<EngineStatus> = _status.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _streamingReply = MutableStateFlow("")
    val streamingReply: StateFlow<String> = _streamingReply.asStateFlow()

    fun loadModel(
        modelPath: String,
        backendName: String,
        systemInstruction: String,
        topK: Int,
        topP: Double,
        temperature: Double
    ) {
        scope.launch {
            mutex.withLock {
                val file = File(modelPath)
                if (!file.exists() || !file.isFile) {
                    _status.value = EngineStatus.Error("Arquivo do modelo não encontrado em: $modelPath")
                    return@withLock
                }
                if (engine?.engineConfig?.modelPath == modelPath && loadedBackendName == backendName && _status.value is EngineStatus.Ready) {
                    return@withLock
                }

                releaseInternal()
                _status.value = EngineStatus.Loading(file.name, backendName)

                try {
                    val backend = if (backendName == "GPU") Backend.GPU() else Backend.CPU()
                    val config = EngineConfig(
                        modelPath = modelPath,
                        backend = backend,
                        cacheDir = app.cacheDir.path
                    )
                    val initializedEngine = Engine(config).also { it.initialize() }
                    engine = initializedEngine
                    loadedBackendName = backendName

                    conversation = initializedEngine.createConversation(
                        ConversationConfig(
                            systemInstruction = Contents.of(systemInstruction),
                            samplerConfig = SamplerConfig(
                                topK = topK.coerceIn(1, 100),
                                topP = topP.coerceIn(0.1, 1.0),
                                temperature = temperature.coerceIn(0.0, 2.0)
                            )
                        )
                    )
                    _status.value = EngineStatus.Ready(
                        modelPath = modelPath,
                        modelName = file.name,
                        backendName = backendName
                    )
                } catch (e: Exception) {
                    releaseInternal()
                    _status.value = EngineStatus.Error(
                        e.message ?: "Falha ao inicializar LiteRT-LM ($backendName)."
                    )
                }
            }
        }
    }

    fun resetConversation(
        systemInstruction: String,
        topK: Int,
        topP: Double,
        temperature: Double
    ) {
        scope.launch {
            mutex.withLock {
                val currentEngine = engine ?: return@withLock
                while (_isGenerating.value) {
                    conversation?.cancelProcess()
                    delay(100)
                }
                conversation?.close()
                conversation = null
                conversation = currentEngine.createConversation(
                    ConversationConfig(
                        systemInstruction = Contents.of(systemInstruction),
                        samplerConfig = SamplerConfig(
                            topK = topK.coerceIn(1, 100),
                            topP = topP.coerceIn(0.1, 1.0),
                            temperature = temperature.coerceIn(0.0, 2.0)
                        )
                    )
                )
                _streamingReply.value = ""
            }
        }
    }

    fun generateReply(
        prompt: String,
        onComplete: (Result<String>) -> Unit
    ) {
        scope.launch {
            val activeConversation = conversation
            if (_status.value !is EngineStatus.Ready || activeConversation == null || _isGenerating.value) {
                return@launch
            }
            _isGenerating.value = true
            _streamingReply.value = ""
            val sb = StringBuilder()
            try {
                val replies = activeConversation.sendMessageAsync(prompt)
                replies.collect { chunk ->
                    val piece = chunk.toString()
                    sb.append(piece)
                    _streamingReply.value = sb.toString()
                }
                onComplete(Result.success(sb.toString().trim()))
            } catch (e: CancellationException) {
                onComplete(Result.success(sb.toString().trim()))
                throw e
            } catch (e: Exception) {
                onComplete(Result.failure(e))
            } finally {
                _isGenerating.value = false
                _streamingReply.value = ""
            }
        }
    }

    fun stopGeneration() {
        scope.launch {
            conversation?.cancelProcess()
        }
    }

    fun unloadModel() {
        scope.launch {
            mutex.withLock {
                releaseInternal()
            }
        }
    }

    private suspend fun releaseInternal() {
        if (_status.value is EngineStatus.Ready) {
            _status.value = EngineStatus.Unloaded
        }
        while (_isGenerating.value) {
            conversation?.cancelProcess()
            delay(100)
        }
        try {
            conversation?.close()
        } catch (_: Exception) {
        } finally {
            conversation = null
        }
        try {
            engine?.close()
        } catch (_: Exception) {
        } finally {
            engine = null
        }
        _status.value = EngineStatus.Unloaded
    }

    fun shutdown() {
        scope.launch {
            mutex.withLock {
                releaseInternal()
            }
            executor.shutdown()
        }.invokeOnCompletion {
            scope.cancel()
        }
    }
}
