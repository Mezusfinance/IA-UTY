package com.example.ai

import com.example.data.local.KnowledgeChunkEntity
import com.example.data.local.TermWeightEntity
import com.example.data.local.TrainingExampleEntity
import kotlin.math.sqrt

data class RetrievedContext(
    val chunk: KnowledgeChunkEntity,
    val score: Float
)

class LocalRetriever {

    fun retrieve(
        query: String,
        chunks: List<KnowledgeChunkEntity>,
        terms: List<TermWeightEntity>,
        topK: Int = 4
    ): List<RetrievedContext> {
        if (query.isBlank() || chunks.isEmpty()) return emptyList()
        val queryTokens = TextTokenizer.tokenize(query)
        val normQuery = TextTokenizer.normalize(query)
        if (queryTokens.isEmpty() && normQuery.isEmpty()) return emptyList()

        val termMap = terms.associateBy { it.term }
        val avgLen = chunks.map { it.tokenCount }.average().toFloat().coerceAtLeast(1f)

        val scored = chunks.mapNotNull { chunk ->
            val chunkTokens = TextTokenizer.tokenize(chunk.text)
            if (chunkTokens.isEmpty()) return@mapNotNull null

            val tfCounts = chunkTokens.groupingBy { it }.eachCount()
            val docLen = chunkTokens.size.toFloat()
            val k1 = 1.5f
            val b = 0.75f

            var bm25 = 0f
            var matchedTerms = 0
            for (qTerm in queryTokens.distinct()) {
                val tf = tfCounts[qTerm]?.toFloat() ?: 0f
                if (tf > 0f) {
                    matchedTerms++
                    val termStats = termMap[qTerm]
                    val idf = termStats?.idf ?: 1.0f
                    val learnedW = termStats?.learnedWeight ?: 1.0f
                    val normFactor = tf * (k1 + 1f) / (tf + k1 * (1f - b + b * (docLen / avgLen)))
                    bm25 += idf * learnedW * normFactor
                }
            }

            // Phrase / substring boost
            val normText = TextTokenizer.normalize(chunk.text)
            val phraseBoost = if (normQuery.length >= 4 && normText.contains(normQuery)) 3.5f else 0f

            val coverage = if (queryTokens.isNotEmpty()) {
                matchedTerms.toFloat() / queryTokens.distinct().size.toFloat()
            } else 0f

            val totalScore = (bm25 + phraseBoost) * chunk.weightBoost * (0.65f + 0.35f * coverage)
            if (totalScore > 0.05f) RetrievedContext(chunk, totalScore) else null
        }

        // Normalize top scores into [0.0..0.99] confidence display
        val top = scored.sortedByDescending { it.score }.take(topK)
        if (top.isEmpty()) return emptyList()
        val maxScore = top.first().score.coerceAtLeast(1f)
        val normDenom = sqrt(maxScore * maxScore + 4f)
        return top.map { item ->
            item.copy(score = (item.score / normDenom).coerceIn(0.1f, 0.99f))
        }
    }

    fun buildAugmentedPrompt(
        userQuery: String,
        retrieved: List<RetrievedContext>,
        examples: List<TrainingExampleEntity>
    ): String {
        if (retrieved.isEmpty() && examples.isEmpty()) return userQuery

        val sb = StringBuilder()
        if (retrieved.isNotEmpty()) {
            sb.appendLine("### CONTEXTO TREINADO DA PASTA LOCAL (USE COMO FONTE PRIORITÁRIA):")
            retrieved.forEachIndexed { idx, item ->
                sb.appendLine("[Fonte ${idx + 1}: ${item.chunk.documentName}]")
                sb.appendLine(item.chunk.text.trim())
                sb.appendLine()
            }
        }
        if (examples.isNotEmpty()) {
            sb.appendLine("### REGRAS E PARES DE INSTRUÇÃO APRENDIDOS:")
            examples.take(5).forEach { ex ->
                sb.appendLine("- Quando perguntado sobre \"${ex.questionPattern}\": ${ex.expectedContext}")
            }
            sb.appendLine()
        }
        sb.appendLine("### PERGUNTA DO USUÁRIO:")
        sb.append(userQuery)
        return sb.toString()
    }

    fun buildSystemInstruction(
        basePersona: String,
        examples: List<TrainingExampleEntity>
    ): String {
        if (examples.isEmpty()) return basePersona
        val sb = StringBuilder(basePersona.trim())
        sb.appendLine("\n\nDiretrizes aprendidas pelo usuário:")
        examples.take(8).forEach { ex ->
            sb.appendLine("• [${ex.questionPattern}] -> ${ex.expectedContext}")
        }
        return sb.toString()
    }

    fun synthesizeExtractiveReply(
        query: String,
        retrieved: List<RetrievedContext>,
        totalTrainedChunks: Int
    ): String {
        if (totalTrainedChunks == 0) {
            return buildString {
                appendLine("Modo Extrativo Local ativo (nenhum modelo neural .litertlm carregado ainda).")
                appendLine()
                appendLine("Ainda não há dados treinados na base local.")
                appendLine("1. Abra a aba **Pasta** para vincular uma pasta do celular ou criar notas.")
                appendLine("2. Abra **Treinar** para indexar e treinar o conhecimento local.")
                append("3. Abra **Motor** para importar ou baixar um modelo `.litertlm` e ativar respostas neurais completas off-line.")
            }
        }
        if (retrieved.isEmpty()) {
            return buildString {
                appendLine("Consultei os $totalTrainedChunks fragmentos treinados da sua pasta local, mas não encontrei correspondência direta para \"$query\".")
                appendLine()
                append("Dica: tente usar palavras-chave presentes nos seus arquivos ou carregue um modelo neural `.litertlm` na aba **Motor** para raciocínio generativo completo off-line.")
            }
        }
        return buildString {
            appendLine("Resposta baseada diretamente nos dados treinados da sua pasta (Modo Extrativo Local — carregue um `.litertlm` em **Motor** para síntese neural completa):")
            appendLine()
            retrieved.forEachIndexed { idx, ctx ->
                val pct = (ctx.score * 100).toInt()
                appendLine("${idx + 1}. **${ctx.chunk.documentName}** (${pct}% de aderência)")
                appendLine(ctx.chunk.text.trim())
                if (idx < retrieved.lastIndex) appendLine()
            }
        }
    }
}
