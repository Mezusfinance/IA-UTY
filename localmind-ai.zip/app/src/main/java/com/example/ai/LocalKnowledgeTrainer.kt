package com.example.ai

import com.example.data.local.DataDocumentEntity
import com.example.data.local.KnowledgeChunkEntity
import com.example.data.local.TermWeightEntity
import com.example.data.local.TrainingExampleEntity
import com.example.data.local.TrainingRunEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.Normalizer
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

data class TrainingProgress(
    val isRunning: Boolean = false,
    val stageLabel: String = "",
    val currentEpoch: Int = 0,
    val totalEpochs: Int = 0,
    val progress: Float = 0f,
    val lossCurve: List<Float> = emptyList(),
    val chunksBuilt: Int = 0,
    val vocabSize: Int = 0
)

data class TrainingOutput(
    val chunks: List<KnowledgeChunkEntity>,
    val terms: List<TermWeightEntity>,
    val docChunkCounts: Map<Long, Int>,
    val run: TrainingRunEntity
)

object TextTokenizer {
    private val DIACRITICS_REGEX = "\\p{InCombiningDiacriticalMarks}+".toRegex()
    private val NON_ALNUM_REGEX = "[^a-z0-9\\s]".toRegex()
    private val WHITESPACE_REGEX = "\\s+".toRegex()

    private val STOP_WORDS = setOf(
        "a", "o", "as", "os", "um", "uma", "uns", "umas", "de", "do", "da", "dos", "das",
        "em", "no", "na", "nos", "nas", "por", "para", "com", "sem", "sob", "sobre",
        "entre", "ate", "apos", "e", "ou", "mas", "que", "se", "como", "quando", "onde",
        "qual", "quais", "quem", "isso", "isto", "aquilo", "este", "esta", "esse", "essa",
        "ele", "ela", "eles", "elas", "meu", "minha", "seu", "sua", "nosso", "nossa",
        "ser", "estar", "ter", "haver", "foi", "era", "sao", "tem", "the", "and", "for",
        "that", "this", "with", "from", "are", "was", "were", "is", "in", "on", "of", "to"
    )

    fun normalize(input: String): String {
        val decomposed = Normalizer.normalize(input.lowercase(), Normalizer.Form.NFD)
        return DIACRITICS_REGEX.replace(decomposed, "")
            .replace(NON_ALNUM_REGEX, " ")
            .replace(WHITESPACE_REGEX, " ")
            .trim()
    }

    fun tokenize(input: String): List<String> {
        val norm = normalize(input)
        if (norm.isEmpty()) return emptyList()
        return norm.split(' ').filter { it.length >= 2 && it !in STOP_WORDS }
    }

    fun topKeywords(tokens: List<String>, maxCount: Int = 8): String {
        if (tokens.isEmpty()) return ""
        return tokens.groupingBy { it }
            .eachCount()
            .entries
            .sortedByDescending { it.value }
            .take(maxCount)
            .joinToString(", ") { it.key }
    }
}

class LocalKnowledgeTrainer {

    suspend fun train(
        documents: List<DataDocumentEntity>,
        examples: List<TrainingExampleEntity>,
        chunkSize: Int,
        overlap: Int,
        epochs: Int,
        onProgress: (TrainingProgress) -> Unit
    ): TrainingOutput = withContext(Dispatchers.Default) {
        val startTime = System.currentTimeMillis()
        val safeChunkSize = chunkSize.coerceIn(180, 1200)
        val safeOverlap = overlap.coerceIn(0, safeChunkSize / 2)
        val safeEpochs = epochs.coerceIn(1, 12)

        onProgress(
            TrainingProgress(
                isRunning = true,
                stageLabel = "Fragmentando documentos locais...",
                currentEpoch = 0,
                totalEpochs = safeEpochs,
                progress = 0.08f
            )
        )

        val chunks = mutableListOf<KnowledgeChunkEntity>()
        val docChunkCounts = mutableMapOf<Long, Int>()
        val now = System.currentTimeMillis()

        // 1. Chunk all linked folder / imported / note documents
        for (doc in documents) {
            val docChunks = splitIntoChunks(doc.contentText, safeChunkSize, safeOverlap)
            docChunkCounts[doc.id] = docChunks.size
            docChunks.forEachIndexed { idx, chunkText ->
                val tokens = TextTokenizer.tokenize(chunkText)
                if (tokens.isNotEmpty()) {
                    chunks.add(
                        KnowledgeChunkEntity(
                            documentId = doc.id,
                            documentName = doc.fileName,
                            chunkIndex = idx,
                            text = chunkText,
                            keywords = TextTokenizer.topKeywords(tokens),
                            tokenCount = tokens.size,
                            weightBoost = 1.0f,
                            epochTrainedAt = now
                        )
                    )
                }
            }
        }

        // 2. Include user-defined Q&A instruction examples as high-priority chunks
        examples.forEachIndexed { idx, ex ->
            val combined = "Pergunta/Gatilho: ${ex.questionPattern}\nInstrução/Resposta: ${ex.expectedContext}"
            val tokens = TextTokenizer.tokenize(combined)
            if (tokens.isNotEmpty()) {
                chunks.add(
                    KnowledgeChunkEntity(
                        documentId = -1L,
                        documentName = "Regra Aprendida #${idx + 1}",
                        chunkIndex = idx,
                        text = combined,
                        keywords = TextTokenizer.topKeywords(tokens),
                        tokenCount = tokens.size,
                        weightBoost = ex.priorityWeight,
                        epochTrainedAt = now
                    )
                )
            }
        }

        if (chunks.isEmpty()) {
            throw IllegalStateException("Adicione ao menos um arquivo de texto ou regra Q&A antes de treinar.")
        }

        onProgress(
            TrainingProgress(
                isRunning = true,
                stageLabel = "Construindo vocabulário BM25/TF-IDF...",
                currentEpoch = 0,
                totalEpochs = safeEpochs,
                progress = 0.2f,
                chunksBuilt = chunks.size
            )
        )

        // 3. Build document frequency and term frequency statistics
        val tokenizedChunks = chunks.map { TextTokenizer.tokenize(it.text) }
        val docFreq = mutableMapOf<String, Int>()
        val totalFreq = mutableMapOf<String, Int>()

        for (tokens in tokenizedChunks) {
            val unique = tokens.toSet()
            for (term in unique) {
                docFreq[term] = (docFreq[term] ?: 0) + 1
            }
            for (term in tokens) {
                totalFreq[term] = (totalFreq[term] ?: 0) + 1
            }
        }

        val numDocs = chunks.size.toFloat()
        val idfMap = docFreq.mapValues { (_, df) ->
            ln(((numDocs - df + 0.5f) / (df + 0.5f)) + 1f).coerceAtLeast(0.1f)
        }
        val learnedWeights = idfMap.mapValues { 1.0f }.toMutableMap()

        // 4. Multi-epoch self-retrieval contrastive weight refinement
        val lossCurve = mutableListOf<Float>()
        var finalRetrievalScore = 0f
        val sampleQueries = chunks.mapIndexed { idx, chunk ->
            val kws = chunk.keywords.split(", ").filter { it.isNotBlank() }.take(3)
            idx to kws
        }.filter { it.second.isNotEmpty() }

        for (epoch in 1..safeEpochs) {
            var epochLoss = 0f
            var top1Hits = 0
            val lr = 0.18f / (1f + 0.2f * (epoch - 1))

            for ((targetIdx, queryTerms) in sampleQueries) {
                var targetScore = 0f
                var bestNegativeScore = 0f

                // Evaluate BM25-weighted score on target vs hard negative sample
                val targetTokens = tokenizedChunks[targetIdx]
                for (q in queryTerms) {
                    val tf = targetTokens.count { it == q }.toFloat()
                    val idf = idfMap[q] ?: 0.5f
                    val w = learnedWeights[q] ?: 1f
                    targetScore += idf * w * ((tf * 2.2f) / (tf + 1.2f))
                }

                if (chunks.size > 1) {
                    val negIdx = (targetIdx + epoch) % chunks.size
                    if (negIdx != targetIdx) {
                        val negTokens = tokenizedChunks[negIdx]
                        for (q in queryTerms) {
                            val tf = negTokens.count { it == q }.toFloat()
                            val idf = idfMap[q] ?: 0.5f
                            val w = learnedWeights[q] ?: 1f
                            bestNegativeScore += idf * w * ((tf * 2.2f) / (tf + 1.2f))
                        }
                    }
                }

                val margin = targetScore - bestNegativeScore
                val loss = max(0f, 1.5f - margin)
                epochLoss += loss
                if (margin > 0f || chunks.size == 1) top1Hits++

                // Reinforce discriminative query terms when margin is tight
                if (loss > 0f) {
                    for (q in queryTerms) {
                        val current = learnedWeights[q] ?: 1f
                        learnedWeights[q] = (current + lr * (loss / 1.5f)).coerceIn(0.5f, 3.5f)
                    }
                }
            }

            val avgLoss = if (sampleQueries.isNotEmpty()) epochLoss / sampleQueries.size else 0f
            finalRetrievalScore = if (sampleQueries.isNotEmpty()) {
                (top1Hits.toFloat() / sampleQueries.size.toFloat()).coerceIn(0f, 1f)
            } else 1f
            lossCurve.add(avgLoss)

            val fraction = 0.25f + (0.7f * (epoch.toFloat() / safeEpochs.toFloat()))
            onProgress(
                TrainingProgress(
                    isRunning = true,
                    stageLabel = "Época $epoch/$safeEpochs — Refinando pesos vetoriais...",
                    currentEpoch = epoch,
                    totalEpochs = safeEpochs,
                    progress = fraction,
                    lossCurve = lossCurve.toList(),
                    chunksBuilt = chunks.size,
                    vocabSize = idfMap.size
                )
            )
            delay(140)
        }

        val termEntities = idfMap.entries.map { (term, idf) ->
            TermWeightEntity(
                term = term,
                idf = idf,
                docFreq = docFreq[term] ?: 1,
                totalFreq = totalFreq[term] ?: 1,
                learnedWeight = learnedWeights[term] ?: 1.0f
            )
        }

        val duration = System.currentTimeMillis() - startTime
        val finalLoss = lossCurve.lastOrNull() ?: 0f
        val run = TrainingRunEntity(
            timestamp = System.currentTimeMillis(),
            documentsCount = documents.size,
            chunksCount = chunks.size,
            vocabSize = termEntities.size,
            epochs = safeEpochs,
            chunkSize = safeChunkSize,
            overlap = safeOverlap,
            finalLoss = finalLoss,
            retrievalScore = finalRetrievalScore,
            durationMs = duration,
            lossCurveCsv = lossCurve.joinToString(",") { String.format(java.util.Locale.US, "%.4f", it) }
        )

        onProgress(
            TrainingProgress(
                isRunning = false,
                stageLabel = "Treinamento concluído!",
                currentEpoch = safeEpochs,
                totalEpochs = safeEpochs,
                progress = 1f,
                lossCurve = lossCurve,
                chunksBuilt = chunks.size,
                vocabSize = termEntities.size
            )
        )

        TrainingOutput(
            chunks = chunks,
            terms = termEntities,
            docChunkCounts = docChunkCounts,
            run = run
        )
    }

    private fun splitIntoChunks(text: String, chunkSize: Int, overlap: Int): List<String> {
        val cleaned = text.replace("\r\n", "\n").trim()
        if (cleaned.isEmpty()) return emptyList()
        if (cleaned.length <= chunkSize) return listOf(cleaned)

        val result = mutableListOf<String>()
        var start = 0
        val step = max(60, chunkSize - overlap)
        while (start < cleaned.length) {
            var end = min(cleaned.length, start + chunkSize)
            if (end < cleaned.length) {
                val breakIdx = cleaned.lastIndexOfAny(charArrayOf('\n', '.', ';', ' '), end)
                if (breakIdx > start + (chunkSize / 2)) {
                    end = breakIdx + 1
                }
            }
            val slice = cleaned.substring(start, end).trim()
            if (slice.isNotEmpty()) {
                result.add(slice)
            }
            if (end >= cleaned.length) break
            start += step
        }
        return result
    }
}
