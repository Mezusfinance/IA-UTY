package com.example.ai

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.os.StatFs
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

data class InstalledModelFile(
    val name: String,
    val path: String,
    val sizeBytes: Long
)

data class CatalogModelSpec(
    val id: String,
    val title: String,
    val fileName: String,
    val repo: String,
    val sizeLabel: String,
    val minBytesThreshold: Long,
    val ramRequirementLabel: String,
    val summary: String
) {
    val downloadUrl: String
        get() = "https://huggingface.co/$repo/resolve/main/$fileName"
}

data class ModelTransferState(
    val isTransferring: Boolean = false,
    val modelName: String = "",
    val bytesTransferred: Long = 0L,
    val totalBytes: Long = 0L,
    val error: String? = null
)

data class DeviceHardwareInfo(
    val totalRamMb: Long,
    val availableRamMb: Long,
    val freeStorageGb: Double
)

class ModelStorageManager(private val context: Context) {

    val modelsDir: File
        get() = File(context.filesDir, "models").apply { if (!exists()) mkdirs() }

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private var activeCall: Call? = null

    private val _transferState = MutableStateFlow(ModelTransferState())
    val transferState: StateFlow<ModelTransferState> = _transferState.asStateFlow()

    val recommendedCatalog = listOf(
        CatalogModelSpec(
            id = "qwen3-0.6b",
            title = "Qwen3 0.6B (Compacto)",
            fileName = "Qwen3-0.6B.litertlm",
            repo = "litert-community/Qwen3-0.6B",
            sizeLabel = "~614 MB",
            minBytesThreshold = 100_000_000L,
            ramRequirementLabel = "3 GB+ RAM",
            summary = "Leve e rápido em CPU ou GPU. Excelente equilíbrio para celulares intermediários rodando 100% off-line."
        ),
        CatalogModelSpec(
            id = "gemma-4-e2b",
            title = "Gemma 4 E2B Instruct",
            fileName = "gemma-4-E2B-it.litertlm",
            repo = "litert-community/gemma-4-E2B-it-litert-lm",
            sizeLabel = "~2.6 GB",
            minBytesThreshold = 500_000_000L,
            ramRequirementLabel = "6 GB+ RAM",
            summary = "Maior compreensão de contexto e raciocínio sobre documentos longos da pasta vinculada."
        )
    )

    fun listInstalledModels(): List<InstalledModelFile> {
        return modelsDir.listFiles()
            ?.filter { it.isFile && it.name.endsWith(".litertlm", ignoreCase = true) }
            ?.sortedByDescending { it.lastModified() }
            ?.map {
                InstalledModelFile(
                    name = it.name,
                    path = it.absolutePath,
                    sizeBytes = it.length()
                )
            } ?: emptyList()
    }

    fun deleteModel(path: String): Boolean {
        val file = File(path)
        return if (file.exists() && file.parentFile?.absolutePath == modelsDir.absolutePath) {
            file.delete()
        } else false
    }

    fun getHardwareInfo(): DeviceHardwareInfo {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)

        val stat = StatFs(Environment.getDataDirectory().path)
        val freeStorageBytes = stat.availableBlocksLong * stat.blockSizeLong

        return DeviceHardwareInfo(
            totalRamMb = memInfo.totalMem / (1024L * 1024L),
            availableRamMb = memInfo.availMem / (1024L * 1024L),
            freeStorageGb = freeStorageBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
        )
    }

    suspend fun importModelFromUri(uri: Uri): Result<InstalledModelFile> = withContext(Dispatchers.IO) {
        var displayName = "modelo_local.litertlm"
        var totalSize = 0L
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIdx >= 0) displayName = cursor.getString(nameIdx) ?: displayName
                if (sizeIdx >= 0) totalSize = cursor.getLong(sizeIdx)
            }
        }
        val safeName = if (displayName.endsWith(".litertlm", ignoreCase = true)) {
            displayName.replace("[^A-Za-z0-9._-]".toRegex(), "_")
        } else {
            "${displayName.replace("[^A-Za-z0-9._-]".toRegex(), "_")}.litertlm"
        }

        val destFile = File(modelsDir, safeName)
        val partFile = File(modelsDir, "$safeName.part")

        _transferState.value = ModelTransferState(
            isTransferring = true,
            modelName = safeName,
            bytesTransferred = 0L,
            totalBytes = totalSize
        )

        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(partFile).use { output ->
                    val buffer = ByteArray(64 * 1024)
                    var copied = 0L
                    while (true) {
                        val read = input.read(buffer)
                        if (read <= 0) break
                        output.write(buffer, 0, read)
                        copied += read
                        _transferState.value = _transferState.value.copy(bytesTransferred = copied)
                    }
                }
            } ?: throw IllegalStateException("Não foi possível ler o arquivo selecionado.")

            if (destFile.exists()) destFile.delete()
            if (!partFile.renameTo(destFile)) {
                throw IllegalStateException("Falha ao salvar o modelo localmente.")
            }

            _transferState.value = ModelTransferState()
            Result.success(InstalledModelFile(destFile.name, destFile.absolutePath, destFile.length()))
        } catch (e: Exception) {
            partFile.delete()
            _transferState.value = ModelTransferState(error = e.message ?: "Erro ao importar modelo")
            Result.failure(e)
        }
    }

    suspend fun downloadCatalogModel(spec: CatalogModelSpec): Result<InstalledModelFile> = withContext(Dispatchers.IO) {
        val destFile = File(modelsDir, spec.fileName)
        val partFile = File(modelsDir, "${spec.fileName}.part")

        _transferState.value = ModelTransferState(
            isTransferring = true,
            modelName = spec.title,
            bytesTransferred = 0L,
            totalBytes = 0L
        )

        try {
            val request = Request.Builder().url(spec.downloadUrl).build()
            val call = client.newCall(request)
            activeCall = call

            call.execute().use { response ->
                if (!response.isSuccessful) {
                    throw IllegalStateException("Servidor retornou código HTTP ${response.code}.")
                }
                val body = response.body ?: throw IllegalStateException("Resposta vazia do servidor.")
                val contentLength = body.contentLength()
                _transferState.value = _transferState.value.copy(totalBytes = contentLength)

                body.byteStream().use { input ->
                    FileOutputStream(partFile).use { output ->
                        val buffer = ByteArray(64 * 1024)
                        var downloaded = 0L
                        while (true) {
                            val read = input.read(buffer)
                            if (read <= 0) break
                            output.write(buffer, 0, read)
                            downloaded += read
                            _transferState.value = _transferState.value.copy(bytesTransferred = downloaded)
                        }
                    }
                }
            }

            if (partFile.length() < spec.minBytesThreshold) {
                throw IllegalStateException("Arquivo baixado está incompleto (${partFile.length()} bytes).")
            }

            if (destFile.exists()) destFile.delete()
            if (!partFile.renameTo(destFile)) {
                throw IllegalStateException("Não foi possível finalizar o arquivo do modelo.")
            }

            _transferState.value = ModelTransferState()
            Result.success(InstalledModelFile(destFile.name, destFile.absolutePath, destFile.length()))
        } catch (e: Exception) {
            partFile.delete()
            _transferState.value = ModelTransferState(error = e.message ?: "Download cancelado ou falhou.")
            Result.failure(e)
        } finally {
            activeCall = null
        }
    }

    fun cancelTransfer() {
        activeCall?.cancel()
        activeCall = null
    }

    fun clearTransferError() {
        if (!_transferState.value.isTransferring) {
            _transferState.value = ModelTransferState()
        }
    }
}
