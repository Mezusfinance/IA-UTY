package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.MainViewModel
import com.example.ui.navigation.APP_TABS
import com.example.ui.navigation.AppRoute
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.DataFolderScreen
import com.example.ui.screens.ModelManagerScreen
import com.example.ui.screens.TrainingScreen
import com.example.ui.theme.NucleoIATheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NucleoIAApp()
        }
    }
}

@Composable
fun NucleoIAApp(viewModel: MainViewModel = viewModel()) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val documents by viewModel.documents.collectAsStateWithLifecycle()
    val trainedChunkCount by viewModel.trainedChunkCount.collectAsStateWithLifecycle()
    val vocabSize by viewModel.vocabSize.collectAsStateWithLifecycle()
    val trainingProgress by viewModel.trainingProgress.collectAsStateWithLifecycle()
    val trainingExamples by viewModel.trainingExamples.collectAsStateWithLifecycle()
    val trainingRuns by viewModel.trainingRuns.collectAsStateWithLifecycle()
    val chatMessages by viewModel.chatMessages.collectAsStateWithLifecycle()
    val engineStatus by viewModel.engineStatus.collectAsStateWithLifecycle()
    val isGenerating by viewModel.isGenerating.collectAsStateWithLifecycle()
    val streamingReply by viewModel.streamingReply.collectAsStateWithLifecycle()
    val installedModels by viewModel.installedModels.collectAsStateWithLifecycle()
    val detectedModels by viewModel.detectedModelsInFolder.collectAsStateWithLifecycle()
    val transferState by viewModel.transferState.collectAsStateWithLifecycle()
    val hardwareInfo by viewModel.hardwareInfo.collectAsStateWithLifecycle()
    val isScanningFolder by viewModel.isScanningFolder.collectAsStateWithLifecycle()
    val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(statusBanner) {
        statusBanner?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusBanner()
        }
    }

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    val navigateToTab: (AppRoute) -> Unit = { target ->
        navController.navigate(target) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    NucleoIATheme(darkTheme = settings.darkTheme) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useRail = maxWidth >= 600.dp

            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                contentWindowInsets = WindowInsets.safeDrawing,
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                bottomBar = {
                    if (!useRail) {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface
                        ) {
                            APP_TABS.forEach { tab ->
                                val selected = currentDestination?.hasRoute(tab.route::class) == true
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { navigateToTab(tab.route) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = tab.label
                                        )
                                    },
                                    label = { Text(tab.label) },
                                    modifier = Modifier.testTag(tab.testTag)
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (useRail) {
                        NavigationRail(
                            containerColor = MaterialTheme.colorScheme.surface,
                            modifier = Modifier.fillMaxHeight()
                        ) {
                            APP_TABS.forEach { tab ->
                                val selected = currentDestination?.hasRoute(tab.route::class) == true
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { navigateToTab(tab.route) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = tab.label
                                        )
                                    },
                                    label = { Text(tab.label) },
                                    modifier = Modifier.testTag(tab.testTag)
                                )
                            }
                        }
                    }

                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.TopCenter
                    ) {
                        NavHost(
                            navController = navController,
                            startDestination = AppRoute.Chat,
                            modifier = Modifier
                                .fillMaxSize()
                                .widthIn(max = 760.dp)
                        ) {
                            composable<AppRoute.Chat> {
                                ChatScreen(
                                    messages = chatMessages,
                                    engineStatus = engineStatus,
                                    isGenerating = isGenerating,
                                    streamingReply = streamingReply,
                                    useTrainedContext = settings.useTrainedContext,
                                    trainedChunkCount = trainedChunkCount,
                                    onSendMessage = viewModel::sendUserMessage,
                                    onStopGeneration = viewModel::stopGeneration,
                                    onNewSession = viewModel::startNewChatSession,
                                    onToggleTrainedContext = viewModel::toggleUseTrainedContext,
                                    onNavigateToFolder = { navigateToTab(AppRoute.Folder) },
                                    onNavigateToEngine = { navigateToTab(AppRoute.Engine) }
                                )
                            }

                            composable<AppRoute.Folder> {
                                DataFolderScreen(
                                    linkedFolderName = settings.linkedFolderName,
                                    linkedFolderUri = settings.linkedFolderUri,
                                    documents = documents,
                                    detectedModels = detectedModels,
                                    isScanning = isScanningFolder,
                                    onLinkFolder = viewModel::linkFolder,
                                    onResyncFolder = viewModel::resyncLinkedFolder,
                                    onUnlinkFolder = viewModel::unlinkFolder,
                                    onImportFile = viewModel::importDocumentFile,
                                    onCreateNote = viewModel::createLocalNote,
                                    onDeleteDocument = viewModel::deleteDocument,
                                    onImportDetectedModel = { uri ->
                                        viewModel.importModelFile(uri, autoLoad = true)
                                        navigateToTab(AppRoute.Engine)
                                    },
                                    onGoToTraining = { navigateToTab(AppRoute.Train) }
                                )
                            }

                            composable<AppRoute.Train> {
                                TrainingScreen(
                                    settings = settings,
                                    documentsCount = documents.size,
                                    trainedChunkCount = trainedChunkCount,
                                    vocabSize = vocabSize,
                                    trainingProgress = trainingProgress,
                                    examples = trainingExamples,
                                    trainingRuns = trainingRuns,
                                    onUpdateHyperparams = viewModel::updateHyperparameters,
                                    onStartTraining = viewModel::startTraining,
                                    onAddExample = viewModel::addTrainingExample,
                                    onDeleteExample = viewModel::deleteTrainingExample
                                )
                            }

                            composable<AppRoute.Engine> {
                                ModelManagerScreen(
                                    settings = settings,
                                    engineStatus = engineStatus,
                                    installedModels = installedModels,
                                    catalogModels = viewModel.modelStorage.recommendedCatalog,
                                    transferState = transferState,
                                    hardwareInfo = hardwareInfo,
                                    onRefreshHardware = viewModel::refreshHardwareAndModels,
                                    onSelectBackend = viewModel::setPreferredBackend,
                                    onImportModelUri = { uri -> viewModel.importModelFile(uri, autoLoad = true) },
                                    onLoadModel = { path -> viewModel.loadLocalModel(path, settings.activeBackend) },
                                    onUnloadModel = viewModel::unloadModel,
                                    onDeleteModel = viewModel::deleteInstalledModel,
                                    onDownloadCatalogModel = viewModel::downloadCatalogModel,
                                    onCancelTransfer = viewModel::cancelModelTransfer,
                                    onToggleStrictOffline = viewModel::toggleStrictOffline,
                                    onToggleDarkTheme = viewModel::toggleDarkTheme
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
