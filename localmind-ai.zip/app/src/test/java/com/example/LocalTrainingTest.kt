package com.example

import com.example.ai.LocalKnowledgeTrainer
import com.example.ai.LocalRetriever
import com.example.data.local.DataDocumentEntity
import com.example.data.local.TrainingExampleEntity
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LocalTrainingTest {

    @Test
    fun trainerAndRetrieverWorkOfflineWithPortugueseDocuments() = runBlocking {
        val docs = listOf(
            DataDocumentEntity(
                id = 1L,
                uriString = "local://nota/1",
                fileName = "protocolo_energia.md",
                mimeType = "text/markdown",
                sizeBytes = 250L,
                lastModified = 1000L,
                contentText = "O sistema de energia solar híbrido da fazenda utiliza inversor de 15 kW e banco de baterias LiFePO4 de 48V para operação noturna off-line.",
                sourceType = "NOTE"
            ),
            DataDocumentEntity(
                id = 2L,
                uriString = "local://nota/2",
                fileName = "receita_cafe.txt",
                mimeType = "text/plain",
                sizeBytes = 180L,
                lastModified = 1000L,
                contentText = "Para preparar café filtrado especial, utilize 18 gramas de grão moído médio para 300 ml de água a 93 graus Celsius.",
                sourceType = "NOTE"
            )
        )
        val examples = listOf(
            TrainingExampleEntity(
                id = 1L,
                questionPattern = "qual a tensao das baterias",
                expectedContext = "Sempre informe que o banco LiFePO4 opera em 48V nominais."
            )
        )

        val trainer = LocalKnowledgeTrainer()
        val output = trainer.train(
            documents = docs,
            examples = examples,
            chunkSize = 300,
            overlap = 50,
            epochs = 4,
            onProgress = {}
        )

        assertTrue("Chunks should be generated", output.chunks.isNotEmpty())
        assertTrue("Vocabulary should be non-empty", output.terms.isNotEmpty())
        assertEquals(4, output.run.epochs)

        val retriever = LocalRetriever()
        val results = retriever.retrieve(
            query = "qual a potencia do inversor e bateria LiFePO4",
            chunks = output.chunks,
            terms = output.terms,
            topK = 2
        )

        assertTrue("Retriever should return matching chunk", results.isNotEmpty())
        assertTrue(
            "Top chunk should come from protocolo_energia.md or learned rule",
            results.first().chunk.documentName.contains("protocolo_energia") ||
                results.first().chunk.documentName.contains("Regra Aprendida")
        )
    }
}
